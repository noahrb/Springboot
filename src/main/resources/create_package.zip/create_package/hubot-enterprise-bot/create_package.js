/**
 * Notes:
 * © Copyright 2017 EntIT Software LLC, a Micro Focus company
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Note:
//
// NO_PACKAGING: This file is a development artifact and should not be packaged for distribution

// Function to return a date in YYYYMMDD format

Date.prototype.yyyymmdd = function() {
  let mm = this.getMonth() + 1; // getMonth() is zero-based
  let dd = this.getDate();
  let hh = this.getHours();
  let min = this.getMinutes();

  return [this.getFullYear(),
          (mm>9 ? '' : '0') + mm,
          (dd>9 ? '' : '0') + dd
         ].join('');
};

// Create a (relatively) unique PACKAGE_VERSION in case it is not specified as environment variable.
// The format aligns to Fedora best practices, .e.g. 0.20170606.git.7f4226c

let exec = require('child_process').execSync;
let env = require('node-env-file');

let pRelease;
let dateString = "0." + new Date().yyyymmdd();
try {
  let gitString = exec('git describe --tags --always').toString();
  let len = gitString.length -1;
  let gitHash = ".git." + gitString.substring(len-7, len);
  pRelease = dateString + gitHash;
} catch (err) {
  pRelease = dateString
}

// Prepare and build the real RPM package

let buildRpm = require('rpm-builder');
let config = require('nconf');
let fs = require('fs');
let path = require('path');
let logger = require('winston');
let _ = require('lodash');

try {
  let REQUIRED_ENV_VARS = [  ];
  config.env();
  config.required(REQUIRED_ENV_VARS);
} catch (err) {
  console.log('There was an issue with your environment variables:');
  console.log(err.message);
  process.exit(1);
}

let packageName = process.env.PACKAGE_NAME || "itom-" + require('./package.json').name;
let packageVersion = process.env.PACKAGE_VERSION || require('./package.json').version;
let packageRelease = process.env.PACKAGE_RELEASE || pRelease;
let arch = process.env.PACKAGE_ARCH || 'noarch';
let envPath = '/etc/opt/microfocus/' + packageName + '/';
let configPath = '/etc/opt/microfocus/' + packageName + '/config/';
let certsPath = '/etc/opt/microfocus/' + packageName + '/certs/';
let docPath = '/opt/microfocus/share/doc/packages/' + packageName + '/';
let codePath = '/opt/microfocus/' + packageName + '/';
let logPath = '/var/opt/microfocus/' + packageName + '/log/';
let filesPath = '/var/opt/microfocus/' + packageName + '/log/files/';
let systemCtlPath = '/usr/lib/systemd/system/';

console.log("PACKAGE_NAME:      " + packageName);
console.log("PACKAGE_VERSION:   " + packageVersion);
console.log("PACKAGE_RELEASE:   " + packageRelease);
console.log("ENV_PATH: " + envPath);
console.log("CERTS_PATH: " + certsPath);
console.log("DOC_PATH: " + docPath);
console.log("CODE_PATH: " + codePath);
console.log("LOG_PATH: " + logPath);

if (_.isNil(packageName) || _.isEmpty(packageName))
  packageName = "hubot-enterprise-bot";

let distPath = path.join(__dirname, "./dist");
let envFile =  "./option.env";
let rpmPath = `${distPath}/rpm`;
let serviceFile =  "./" + packageName + ".service";
let serviceBuffer = "[Unit]\n";
let envBuffer = "NODE_ENV=production";

serviceBuffer += "Description=ChatOpts bot service\n\n";
serviceBuffer += "[Service]\n";
serviceBuffer += "Type=simple\n";
serviceBuffer += "EnvironmentFile=" + envPath + "proxy.env\n";
serviceBuffer += "ExecStart=" + codePath + "run.sh\n";
serviceBuffer += "User=chatopsbot\n\n";
serviceBuffer += "[Install]\n";
serviceBuffer += "WantedBy=multi-user.target\n";

if(fs.existsSync(`${envPath}option.env`)){
  env(`${envPath}option.env`);
  envBuffer = "NODE_ENV=production\nCHAT_PLATFORM_OPTION=" + process.env.CHAT_PLATFORM_OPTION;
}

logger.info(`Creating rpm package at ${rpmPath}`);

fs.existsSync(distPath) || fs.mkdirSync(distPath);
fs.existsSync(rpmPath) || fs.mkdirSync(rpmPath);
fs.writeFileSync(serviceFile, serviceBuffer);
fs.writeFileSync(envFile, envBuffer);

let options = {
  name: packageName,
  version: packageVersion,
  release: packageRelease,
  buildArch: arch,
  rpmDest: rpmPath,
  execOpts: {maxBuffer: 10 * 1e6},
  files: [
    {src: './docs/*', dest: codePath},
    {src: './example/*', dest: codePath},
    {src: './lib/*', dest: codePath},
    {src: './node_modules/*', dest: codePath},
    {src: './third-party-licenses/*', dest: codePath},
    {src: './scripts/*', dest: codePath},
    {src: './src/*', dest: codePath},
    {src: './test/*', dest: codePath},
    {src: './dist.sh', dest: codePath},
    {src: './start.coffee', dest: codePath},
    {src: './configure.sh', dest: codePath},
    {src: './hubot.js', dest: codePath},
    {src: './index.coffee', dest: codePath},
    {src: './bot-app.json', dest: codePath},
    {src: './package.json', dest: codePath},
    {src: './run.sh', dest: codePath},
    {src: './yarn.lock', dest: codePath},
    {src: './locales', dest: codePath},
    {src: './LICENSE', dest: docPath},
    {src: './README.md', dest: docPath},
    {src: './option.env', dest: envPath},
    {src: './' + packageName + '.service', dest: systemCtlPath}
  ],
  preInstallScript: [
    "echo 'Removing directory " + docPath + " ...'",
    "rm -rf " + docPath,
    "echo 'Removing directory " + codePath + " ...'",
    "rm -rf " + codePath,
    "echo 'Removing directory " + filesPath + " ...'",
    "rm -rf " + filesPath,
    "echo 'Removing directory " + configPath + " ...'",
    "rm -rf " + configPath,
    "echo 'Successfully uninstalled " + packageName + ".'"
  ],
  postInstallScript: [
    "echo 'Adding user chatopsbot ...'",
    "groupadd chatopsgroup",
    "useradd -g chatopsgroup -m chatopsbot",
    "echo 'Creating " + envPath + " ...'",
    "mkdir -p " + envPath,
    "echo 'Creating " + certsPath + " ...'",
    "mkdir -p " + certsPath,
    "echo 'Creating " + configPath + " ...'",
    "mkdir -p " + configPath,
    "echo 'Creating " + logPath + " ...'",
    "mkdir -p " + logPath,
    "cp -R " + codePath + "lib/adapters/msteams/manifest " + configPath,
    "echo 'Creating " + packageName + ".service at " + systemCtlPath + " ...'",
    "systemctl daemon-reload",
    "systemctl disable " + packageName + ".service",
    "echo 'Changing owner of " + envPath + " ...'",
    "chown -R chatopsbot:chatopsgroup " + envPath,
    "echo 'Changing owner of " + docPath + " ...'",
    "chown -R chatopsbot:chatopsgroup " + docPath,
    "echo 'Changing owner of " + codePath + " ...'",
    "chown -R chatopsbot:chatopsgroup " + codePath,
    "echo 'Changing owner of " + logPath + " ...'",
    "chown -R chatopsbot:chatopsgroup " + logPath,
    "chown -R chatopsbot:chatopsgroup /var/opt/microfocus/" + packageName,
    "chmod 755 /opt/microfocus",
    "chmod 755 /etc/opt/microfocus",
    "chmod 755 /var/opt/microfocus",
    "chmod 755 /opt/microfocus/share/doc/packages/",
    "echo 'Your env files path: " + envPath + "'",
    "su -c 'find " + envPath + " -type d -exec chmod 700 {} +' chatopsbot",
    "su -c 'find " + envPath + " -type f -exec chmod 600 {} +' chatopsbot",
    "chmod 700 " + configPath + "manifest/create_manifest.sh",
    "echo 'Your certificates files path: " + certsPath + "'",
    "echo 'Your license and readme path: " + docPath + "'",
    "chmod -R 444 " + docPath,
    "chmod 555 " + docPath,
    "echo 'Your root files path: " + codePath + "'",
    "su -c 'find " + codePath + " -type d -exec chmod 700 {} +' chatopsbot",
    "su -c 'find " + codePath + " -type f -exec chmod 500 {} +' chatopsbot",
    "echo 'Your logfiles and temp files path: " + logPath + "'",
    "su -c 'find /var/opt/microfocus/" + packageName + " -type d -exec chmod 700 {} +' chatopsbot",
    "su -c 'find /var/opt/microfocus/" + packageName + " -type f -exec chmod 600 {} +' chatopsbot",
    "echo 'Successfully created a user: chatopsbot.'"
  ],
  preUninstallScript: [
    "service " + packageName + " stop"
  ],
  postUninstallScript: [
    "echo 'Removing directory " + docPath + " ...'",
    "rm -rf " + docPath,
    "echo 'Removing directory " + codePath + " ...'",
    "rm -rf " + codePath,
    "echo 'Removing directory " + filesPath + " ...'",
    "rm -rf " + filesPath,
    "echo 'Removing directory " + configPath + " ...'",
    "rm -rf " + configPath,
    "echo 'Successfully uninstalled " + packageName + ".'"
  ]
};
buildRpm(options, function(err, rpm) {
  if (err) {
    throw err;
  }
  console.log(rpm);
});
