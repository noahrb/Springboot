//  © Copyright 2017 EntIT Software LLC, a Micro Focus company
//
//  Permission is hereby granted, free of charge, to any person obtaining a
//  copy of this software and associated documentation files (the "Software"),
//  to deal in the Software without restriction, including without limitation
//  the rights to use, copy, modify, merge, publish, distribute, sublicense,
//  and/or sell copie of the Software, and to permit persons to whom the
//  Software is furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE.

// Note:
//
// NO_PACKAGING: This file is a development artifact and should not be packaged for distribution 

// Function to return a date in YYYYMMDD format

Date.prototype.yyyymmdd = function() {
  var mm = this.getMonth() + 1; // getMonth() is zero-based
  var dd = this.getDate();
  var hh = this.getHours();
  var min = this.getMinutes();

  return [this.getFullYear(),
          (mm>9 ? '' : '0') + mm,
          (dd>9 ? '' : '0') + dd
         ].join('');
};

// Create a (relatively) unique PACKAGE_VERSION in case it is not specified as environment variable. 
// The format aligns to Fedora best practices, .e.g. 0.20170606.git.7f4226c

var exec = require('child_process').execSync;

let pRelease;
let dateString = "0." + new Date().yyyymmdd();
try {
    let gitString = exec('git describe --tags --always').toString();
    let len = gitString.length -1;
    let gitHash = ".git." + gitString.substring(len-7, len);
    pRelease = dateString + gitHash;
} catch (err) {
    pRelease = dateString
}

// Prepare and build the real RPM package
let buildRpm = require('rpm-builder');
let config = require('nconf');
let fs = require('fs');
let path = require('path');
let logger = require('winston');
let _ = require('lodash');

try {
    let REQUIRED_ENV_VARS = [ ];
    config.env();
    config.required(REQUIRED_ENV_VARS);
} catch (err) {
    console.log('There was an issue with your environment variables:');
    console.log(err.message);
    process.exit(1);
}

let packageName = process.env.PACKAGE_NAME || "itom-" + require('./package.json').name;
let packageVersion = process.env.PACKAGE_VERSION || require('./package.json').version;
let packageRelease = process.env.PACKAGE_RELEASE || pRelease;
let arch = process.env.PACKAGE_ARCH || 'noarch';
let envPath = '/etc/opt/microfocus/' + packageName + '/';
let certsPath = '/etc/opt/microfocus/' + packageName + '/certs/';
let docPath = '/opt/microfocus/share/doc/packages/' + packageName + '/';
let codePath = '/opt/microfocus/' + packageName + '/';
let logPath = '/var/opt/microfocus/' + packageName + '/log/';
let systemCtlPath = '/usr/lib/systemd/system/';

console.log("PACKAGE_NAME:      " + packageName);
console.log("PACKAGE_VERSION:   " + packageVersion);
console.log("PACKAGE_RELEASE:   " + packageRelease);
console.log("ENV_PATH: " + envPath);
console.log("CERTS_PATH: " + certsPath);
console.log("DOC_PATH: " + docPath);
console.log("CODE_PATH: " + codePath);
console.log("LOG_PATH: " + logPath);

if (_.isNil(packageName) || _.isEmpty(packageName))
    packageName = "hubot-enterprise-login";

let distPath = path.join(__dirname, "./dist");
let nodeFile =  "./option.env";
let rpmPath = `${distPath}/rpm`;
let serviceFile =  "./" + packageName + ".service";
let serviceBuffer = "[Unit]\n";
let nodeBuffer = "NODE_ENV=production";

serviceBuffer += "Description=ChatOpts login service\n\n";
serviceBuffer += "[Service]\n";
serviceBuffer += "Type=simple\n";
serviceBuffer += "ExecStart=/usr/bin/node /opt/microfocus/" + packageName + "/login.js\n";
serviceBuffer += "User=chatopslogin\n\n";
serviceBuffer += "[Install]\n";
serviceBuffer += "WantedBy=multi-user.target\n";

logger.info(`Creating rpm package at ${rpmPath}`);

fs.existsSync(distPath) || fs.mkdirSync(distPath);
fs.existsSync(rpmPath) || fs.mkdirSync(rpmPath);
fs.writeFileSync(serviceFile, serviceBuffer);
fs.writeFileSync(nodeFile, nodeBuffer);

let options = {
    name: packageName,
    version: packageVersion,
    release: packageRelease,
    buildArch: arch,
    rpmDest: rpmPath,
    execOpts: {maxBuffer: 10 * 1e6},
    files: [
        {src: './src/*', dest: codePath},
        {src: './docs/*', dest: codePath},
        {src: './node_modules/*', dest: codePath},
        {src: './third-party-licenses/*', dest: codePath},
        {src: './scripts/*', dest: codePath},
        {src: './test/*', dest: codePath},
        {src: './configure.coffee', dest: codePath},
        {src: './configure.sh', dest: codePath},
        {src: './index.js', dest: codePath},
        {src: './login.js', dest: codePath},
        {src: './login-app.json', dest: codePath},
        {src: './package.json', dest: codePath},
        {src: './run.sh', dest: codePath},
        {src: './yarn.lock', dest: codePath},
        {src: './README.md', dest: docPath},
        {src: './option.env', dest: envPath},
        {src: './' + packageName + '.service', dest: systemCtlPath}
    ],
    preInstallScript: [
        "echo 'Removing directory " + docPath + " ...'",
        "rm -rf " + docPath,
        "echo 'Removing directory " + codePath + " ...'",
        "rm -rf " + codePath,
        "echo 'Successfully uninstalled " + packageName + ".'"
    ],
    postInstallScript: [
        "echo 'Adding user chatopslogin ...'",
        "groupadd chatopsgroup",
        "useradd -g chatopsgroup -m chatopslogin",
        "echo 'Creating " + envPath + " ...'",
        "mkdir -p " + envPath,
        "echo 'Creating " + certsPath + " ...'",
        "mkdir -p " + certsPath,
        "echo 'Creating " + logPath + " ...'",
        "mkdir -p " + logPath,
        "echo 'Creating " + packageName + ".service at " + systemCtlPath + " ...'",
        "systemctl daemon-reload",
        "systemctl disable " + packageName + ".service",
        "echo 'Changing owner of " + envPath + " ...'",
        "chown -R chatopslogin:chatopsgroup " + envPath,
        "echo 'Changing owner of " + docPath + " ...'",
        "chown -R chatopslogin:chatopsgroup " + docPath,
        "echo 'Changing owner of " + codePath + " ...'",
        "chown -R chatopslogin:chatopsgroup " + codePath,
        "echo 'Changing owner of " + logPath + " ...'",
        "chown -R chatopslogin:chatopsgroup " + logPath,
        "chown -R chatopslogin:chatopsgroup /var/opt/microfocus/" + packageName,
        "chmod 755 /opt/microfocus",
        "chmod 755 /etc/opt/microfocus",
        "chmod 755 /var/opt/microfocus",
        "chmod 755 /opt/microfocus/share/doc/packages/",
        "echo 'Your env files path: " + envPath + "'",
        "su -c 'find " + envPath + " -type d -exec chmod 700 {} +' chatopslogin",
        "su -c 'find " + envPath + " -type f -exec chmod 600 {} +' chatopslogin",
        "echo 'Your certificates files path: " + certsPath + "'",
        "echo 'Your license and readme path: " + docPath + "'",
        "chmod -R 444 " + docPath,
        "chmod 555 " + docPath,
        "echo 'Your root files path: " + codePath + "'",
        "su -c 'find " + codePath + " -type d -exec chmod 700 {} +' chatopslogin",
        "su -c 'find " + codePath + " -type f -exec chmod 500 {} +' chatopslogin",
        "echo 'Your logfiles and temp files path: " + logPath + "'",
        "su -c 'find /var/opt/microfocus/" + packageName + " -type d -exec chmod 700 {} +' chatopslogin",
        "su -c 'find /var/opt/microfocus/" + packageName + " -type f -exec chmod 600 {} +' chatopslogin",
        "echo 'Successfully created a user: chatopslogin.'"
    ],
    preUninstallScript: [
        "service " + packageName + " stop"
    ],
    postUninstallScript: [
        "echo 'Removing directory " + docPath + " ...'",
        "rm -rf " + docPath,
        "echo 'Removing directory " + codePath + " ...'",
        "rm -rf " + codePath,
        "echo 'Successfully uninstalled " + packageName + ".'"
    ]
};

buildRpm(options, function(err, rpm) {
    if (err) {
        throw err;
    }
    console.log(rpm);
});
